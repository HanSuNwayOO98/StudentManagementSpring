package studentmanagement.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import studentmanagement.model.StudentBean;
import studentmanagement.persistence.dao.CourseDAO;
import studentmanagement.persistence.dao.CourseStudentDAO;
import studentmanagement.persistence.dao.StudentDAO;
import studentmanagement.persistence.dto.CourseResponseDTO;
import studentmanagement.persistence.dto.CourseStudentRequestDTO;
import studentmanagement.persistence.dto.StudentRequestDTO;
import studentmanagement.persistence.dto.StudentResponseDTO;

@Controller
public class StudentController 
{

	@Autowired
	private StudentDAO studentDAO;
	@Autowired
	private CourseStudentDAO courseStudentDAO;
	@Autowired
	private CourseDAO courseDAO;
	
	
	@RequestMapping(value="/studentaddpage",method=RequestMethod.GET)
	public ModelAndView studentaddpage(ModelMap model)
	{
		courseDAO.selectAll();
		  List<CourseResponseDTO> courseList = courseDAO.selectAll();            
          model.addAttribute("courseList", courseList);
  		return new ModelAndView("STU001", "studentbean", new StudentBean());
	}
	 @RequestMapping(value = "/StudentAddPage", method = RequestMethod.POST)
		public String addStu(@ModelAttribute("studentbean") StudentBean studentbean, ModelMap model) {
//insert  
		 List<String> attendArray = studentbean.getStudentCourse();
		 if (studentbean.getStudentName().isBlank() || studentbean.getStudentDob().isBlank() || studentbean.getStudentGender().isBlank()||studentbean.getStudentPhone().isBlank() ||studentbean.getStudentEducation().isBlank() ||studentbean.getStudentId().isBlank()) 
		 {
				return "STU001";
			}else {
				StudentDAO dao = new StudentDAO();
				StudentResponseDTO res = new StudentResponseDTO();
				StudentRequestDTO dto = new StudentRequestDTO();
				CourseStudentDAO csdao = new CourseStudentDAO();
				CourseStudentRequestDTO csdto = new CourseStudentRequestDTO();

				for(String a : attendArray ) {
					csdto.setStudentId(studentbean.getStudentId());
					csdto.setCourseName(a);
					csdao.insertCourseStudentData(csdto);
				}
				dto.setStudentId(studentbean.getStudentId());
				dto.setStudentName(studentbean.getStudentName());
				dto.setStudentDob(studentbean.getStudentDob());
				dto.setStudentGender(studentbean.getStudentGender());
				dto.setStudentPhone(studentbean.getStudentPhone());
				dto.setStudentEducation(studentbean.getStudentEducation());
				dao.insertData(dto);
				
						
				return "redirect:/studentsearchpage";
				
			}
		}
	 //show&search
	 @RequestMapping(value = "/studentsearchpage", method = RequestMethod.GET)
		public ModelAndView stuSearchPage(ModelMap model) 
	 	{
		 
		 	StudentDAO dao = new StudentDAO();
			CourseStudentDAO csdao = new CourseStudentDAO();
			List<StudentResponseDTO> list = dao.selectAll();
			for(StudentResponseDTO a : list) {
				List<String> courselist = csdao.selectOne(a.getStudentId());
				a.setStudentCourse(courselist);   
			}
			model.addAttribute("studentList", list);
			return new ModelAndView("STU003", "studentbean", new StudentBean());
		}
	
	 
	 @RequestMapping(value = "/StudentSearchPage", method = RequestMethod.POST)
		public ModelAndView searchStudent(@ModelAttribute("studentbean") StudentBean studentbean, ModelMap model) 
	 {
		 
		 StudentRequestDTO req = new StudentRequestDTO();
			req.setStudentId(studentbean.getSearchId());
			req.setStudentName(studentbean.getSearchName());

			CourseStudentDAO csdao = new CourseStudentDAO();
			StudentDAO dao = new StudentDAO();
			if(dao.search(req).isEmpty()) {
			
				return new ModelAndView("STU003", "studentbean", new StudentBean());
			}
			else {
				List<StudentResponseDTO> list = dao.search(req);
				for(StudentResponseDTO a : list) {
					List<String> courselist = csdao.selectOne(a.getStudentId());
					a.setStudentCourse(courselist);   
				}
				model.addAttribute("studentList", list);
			
			List<StudentResponseDTO> dto=dao.search(req);
			
			return new ModelAndView("STU003", "studentbean", new StudentBean());
			}
		}
	 
	 //Student Update
	 @RequestMapping(value="studentupdatedpage/{studentId}" ,method=RequestMethod.GET)
		public ModelAndView studentupdatepage(@PathVariable String studentId,ModelMap model)
		{
			StudentRequestDTO dto=new StudentRequestDTO();
			dto.setStudentId(studentId);
			courseDAO.selectAll();
			  List<CourseResponseDTO> courseList = courseDAO.selectAll();            
	          model.addAttribute("courseList", courseList);
			return new ModelAndView("STU002","studentbean",studentDAO.selectOne(dto));
		}
	 @RequestMapping(value = "/studentupdatedpage/UpdateStudentUpdatePage" , method = RequestMethod.POST)
	 public String updateStudent(@ModelAttribute("studentbean")StudentBean studentbean,ModelMap model) {
		 List<String> attendArray = studentbean.getStudentCourse();
			
			
//			
			if (studentbean.getStudentName().isBlank() ) {
				model.addAttribute("errorFill", "Fill the Blank!!!");
				model.addAttribute("studentbean", studentbean);
				return "USR003";
			} else {
				StudentResponseDTO res = new StudentResponseDTO();
				StudentRequestDTO dto = new StudentRequestDTO();
				StudentDAO dao=new StudentDAO();
				CourseStudentDAO csdao = new CourseStudentDAO();
				CourseStudentRequestDTO csdto = new CourseStudentRequestDTO();
				
				csdto.setStudentId(studentbean.getStudentId());
				csdao.deleteCourseStudentData(csdto);
				
				for(String a : attendArray ) {
					csdto.setStudentId(studentbean.getStudentId());
					csdto.setCourseName(a);
					csdao.insertCourseStudentData(csdto);
				}
				dto.setStudentId(studentbean.getStudentId());
				dto.setStudentName(studentbean.getStudentName());
				dto.setStudentDob(studentbean.getStudentDob());
				dto.setStudentGender(studentbean.getStudentGender());
				dto.setStudentPhone(studentbean.getStudentPhone());
				dto.setStudentEducation(studentbean.getStudentEducation());
				
				dao.updateData(dto);
				
				
				return "redirect:/studentsearchpage";

			}
	 }
	 @RequestMapping(value = "/deleteStudent/{studentId}", method = RequestMethod.GET)
		public String deleteStudent(@PathVariable String studentId, ModelMap model) {
		 StudentDAO dao=new StudentDAO();
		 StudentRequestDTO dto = new StudentRequestDTO();
			CourseStudentDAO csdao = new CourseStudentDAO(); 
			CourseStudentRequestDTO csdto = new CourseStudentRequestDTO();
		 dto.setStudentId(studentId);
			csdto.setStudentId(studentId);
			dao.deleteData(dto);
			csdao.deleteCourseStudentData(csdto);
				model.addAttribute("errorFill", "Success delete");
				
				return "redirect:/studentsearchpage";
		}
}