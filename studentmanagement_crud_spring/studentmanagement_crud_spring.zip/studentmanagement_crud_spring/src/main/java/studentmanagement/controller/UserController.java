package studentmanagement.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import studentmanagement.model.UserBean;
import studentmanagement.persistence.dao.UserDAO;
import studentmanagement.persistence.dto.UserRequestDTO;
import studentmanagement.persistence.dto.UserResponseDTO;

@Controller
public class UserController 
{
	@Autowired
	private UserDAO UserDAO;
	

	@RequestMapping(value="/searchUserPage",method=RequestMethod.GET)
	public ModelAndView searchUserPage(ModelMap model)
	{
		UserDAO.selectAll();
		ArrayList<UserResponseDTO> list=UserDAO.selectAll();
		model.addAttribute("list",list);
		return new ModelAndView("USR003", "userbean", new UserBean());
	}
	
	@RequestMapping(value = "/searchUser", method = RequestMethod.POST)
	public ModelAndView searchUser(@ModelAttribute("userbean") UserBean userbean, ModelMap model) 
	{
		UserRequestDTO req = new UserRequestDTO();
		req.setUserId(userbean.getSearchId());
		req.setUserName(userbean.getSearchName());


		UserDAO dao = new UserDAO();
		if(dao.search(req).isEmpty()) {
		
			return new ModelAndView("USR003", "userBean", new UserBean());
		}
		else {

		model.addAttribute("list",dao.search(req));
		List<UserResponseDTO> dto=dao.search(req);
		
		return new ModelAndView("USR003", "userBean", new UserBean());
		}
	}
	

	
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public ModelAndView addUser() 
	{
		return new ModelAndView("USR001", "userbean", new UserBean());
	}
	
	
	@RequestMapping(value = "/adduser", method = RequestMethod.POST)
	public String adduser(@ModelAttribute("userbean") UserBean userbean, ModelMap model) {

		if (userbean.getUserId().isBlank() || userbean.getUserName().isBlank() || userbean.getUserCpass().isBlank()
				|| userbean.getUserRole().isBlank()) {
			model.addAttribute("errorFill", "Fill the Blank!!!");
			return "USR001";
		} else {
			UserRequestDTO dto=new UserRequestDTO();
			dto.setUserId(userbean.getUserId());
			dto.setUserName(userbean.getUserName());
			dto.setUserEmail(userbean.getUserEmail());
			dto.setUserPass(userbean.getUserPass());
			dto.setUserRole(userbean.getUserRole());
			int rs=UserDAO.insertData(dto);
			return "redirect:/searchUserPage";
		}
	}

	@RequestMapping(value="/setupupdateuser/{userid}" ,method=RequestMethod.GET)
	public ModelAndView setupupdateuser(@PathVariable String userid,ModelMap model)
	{
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserId(userid);
		return new ModelAndView("USR002","userbean",UserDAO.selectOne(dto));
	}
	@RequestMapping(value="/setupupdateuser/updateUser",method=RequestMethod.POST)
	public String updateuser(@ModelAttribute("userbean")@Validated UserBean userbean,
			BindingResult bs,ModelMap model)
	{
		if(bs.hasErrors())
		{
			return "USR002";
		}
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserId(userbean.getUserId());
		dto.setUserName(userbean.getUserName());
		dto.setUserEmail(userbean.getUserEmail());
		dto.setUserPass(userbean.getUserPass());
		
		dto.setUserRole(userbean.getUserRole());
	
		
		int rs=UserDAO.updateData(dto);
		
		
			return"redirect:/searchUserPage";
		
		
		
	}
	
	
	@RequestMapping(value="/Deleteuser/{userid}",method=RequestMethod.GET)
	public String Deleteuser(@PathVariable String userid, ModelMap model)
	{
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserId(userid);
		UserDAO.deleteData(dto);
		return "redirect:/searchUserPage";
	}
	
}
