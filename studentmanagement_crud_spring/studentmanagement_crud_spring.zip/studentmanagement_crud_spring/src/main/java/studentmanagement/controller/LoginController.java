package studentmanagement.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import studentmanagement.persistence.dao.UserDAO;
import studentmanagement.persistence.dto.UserResponseDTO;
@Controller
public class LoginController {
	@Autowired
	private UserDAO userDAO ;
	
	@GetMapping("/")
	public String displayLogin() {
		return "LGN001";
	}
	
	@GetMapping("/showMenu")
	public String showMenu(){
		return "MNU001";
	}
	
	@PostMapping("/Login")
	public String login(ModelMap model, @RequestParam("userId") String id, @RequestParam("password") String password, HttpSession session) {
		
		
		ArrayList<UserResponseDTO> list = userDAO.selectAll();
		if(list != null) {			
			for(UserResponseDTO user: list) {
				if( user.getUserId().equals(id) &&
						 user.getUserPass().equals(password)) {
					session.setAttribute("user", user.getUserId()+"-"+user.getUserName());
					session.setAttribute("isLogin","Okay");
					
					return "MNU001";
				}
			}
		}		
		model.addAttribute("error", "Please check your data again! ");
		return "LGN001";		
	}
	
	@GetMapping("/Logout")
	public String logout(HttpSession session) {
		
		session.setAttribute("user", "");
		session.setAttribute("isLogin","");
		System.out.print("here");
		
		session.invalidate();
		return "LGN001";
	}

}
