package studentmanagement.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

public class StudentBean {
	@NotEmpty
	private String studentId;
	@NotEmpty
	private String studentName;
	@NotEmpty
	private String studentDob;
	@NotEmpty
	private String studentGender;
	@NotEmpty
	private String studentPhone;
	@NotEmpty
	private String studentEducation;
	@NotEmpty
	private List<String> studentCourse;
	private String searchId;
	private String searchName;
	private String searchCourse;
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentDob() {
		return studentDob;
	}
	public void setStudentDob(String studentDob) {
		this.studentDob = studentDob;
	}
	public String getStudentGender() {
		return studentGender;
	}
	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}
	public String getStudentPhone() {
		return studentPhone;
	}
	public void setStudentPhone(String studentPhone) {
		this.studentPhone = studentPhone;
	}
	public String getStudentEducation() {
		return studentEducation;
	}
	public void setStudentEducation(String studentEducation) {
		this.studentEducation = studentEducation;
	}
	public List<String> getStudentCourse() {
		return studentCourse;
	}
	public void setStudentCourse(List<String> studentCourse) {
		this.studentCourse = studentCourse;
	}
	public String getSearchId() {
		return searchId;
	}
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	public String getSearchName() {
		return searchName;
	}
	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	public String getSearchCourse() {
		return searchCourse;
	}
	public void setSearchCourse(String searchCourse) {
		this.searchCourse = searchCourse;
	}
	
	
	
}

	
	