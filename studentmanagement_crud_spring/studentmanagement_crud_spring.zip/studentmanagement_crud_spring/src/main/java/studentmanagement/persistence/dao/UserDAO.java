package studentmanagement.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import studentmanagement.model.LoginBean;
import studentmanagement.persistence.dto.UserRequestDTO;
import studentmanagement.persistence.dto.UserResponseDTO;

@Service("UserDAO")
public class UserDAO 
{
	public static Connection con=null;
	static
	{
		con=Myconnection.getConnection();
	}

	public Boolean Login(String user_id,String user_password) {
		boolean login = false;
		UserResponseDTO res = new UserResponseDTO();
		String sql = "select * from user where user_id=? and user_password=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,user_id);
			ps.setString(2,user_password);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				res.setUserId(rs.getString("user_id"));
				res.setUserPass(rs.getString("user_password"));
				 login = true;
			}
		} catch (SQLException e) {
			System.out.println("Database error in search");
			e.printStackTrace();
		}
		return login;

	}
	
	
	
	public int  insertData(UserRequestDTO dto)
	{
		int result=0;
		String sql="insert into user(user_id,user_name,user_email,user_password,user_role)"+
					"values(?,?,?,?,?)";
		try 
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString (1,dto.getUserId());
			ps.setString (2,dto.getUserName());
			ps.setString (3,dto.getUserEmail());
			ps.setString (4,dto.getUserPass());
			ps.setString (5,dto.getUserRole());
			
			result=ps.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return result;
	}
	public int  updateData(UserRequestDTO dto)
	{
		int result=0;
		String sql="update user set user_name=?,user_email=?,user_password=?,user_role=? where user_id=?";
		try 
		{
			PreparedStatement ps=con.prepareStatement(sql);
		
			ps.setString (1,dto.getUserName());
			ps.setString (2,dto.getUserEmail());
			ps.setString (3,dto.getUserPass());
			ps.setString (4,dto.getUserRole());
			ps.setString (5,dto.getUserId());
			result=ps.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return result;
	}
	public int  deleteData(UserRequestDTO dto)
	{
		int result=0;
		String sql="delete from user where user_id=?";
		try 
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString (1,dto.getUserId());
			result=ps.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return result;
	}
	public   UserResponseDTO selectOne(UserRequestDTO dto)
	{
		
		UserResponseDTO res=new UserResponseDTO();
		String sql="select * from user where user_id=?";
		try 
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getUserId());
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				
				res.setUserId(rs.getString("user_id"));
				res.setUserName(rs.getString("user_name"));
				res.setUserEmail(rs.getString("user_email"));
				res.setUserPass(rs.getString("user_password"));
				res.setUserRole(rs.getString("user_role"));
				
				
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return res;
	}
	public   List<UserResponseDTO> search(UserRequestDTO dto)
	{
		
		
		List <UserResponseDTO>list=new ArrayList<>();
		String sql="select * from user where user_id=? or user_name=?";
		try 
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getUserId());
			ps.setString(2,dto.getUserName());
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				
				UserResponseDTO res=new UserResponseDTO();
				res.setUserId(rs.getString("user_id"));
				res.setUserName(rs.getString("user_name"));
				res.setUserEmail(rs.getString("user_email"));
				res.setUserPass(rs.getString("user_password"));
				res.setUserRole(rs.getString("user_role"));
				list.add(res);
				
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return list;
	}
	
	
	public ArrayList<UserResponseDTO>selectAll()
	{
		ArrayList<UserResponseDTO>list=new ArrayList();
		String sql="select * from user";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				UserResponseDTO res=new UserResponseDTO();
				
				res.setUserId(rs.getString("user_id"));
				res.setUserName(rs.getString("user_name"));
				res.setUserEmail(rs.getString("user_email"));
				res.setUserPass(rs.getString("user_password"));
				res.setUserRole(rs.getString("user_role"));
			
				list.add(res);
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<UserResponseDTO>loginUser(LoginBean bean)
	{
		ArrayList<UserResponseDTO>loginlist=new ArrayList();
		String sql="select * from user where user_id='"+bean.getUserId()+"'and password='"+bean.getPassword()+"'";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery(sql);
			while(rs.next())
			{
				UserResponseDTO res=new UserResponseDTO();
				
				res.setUserId(rs.getString("user_id"));
				res.setUserPass(rs.getString("user_password"));
				
				
				
			
				loginlist.add(res);
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return loginlist;
	}


}
