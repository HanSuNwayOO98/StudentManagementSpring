package studentmanagement.persistence.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import studentmanagement.persistence.dto.StudentRequestDTO;
import studentmanagement.persistence.dto.StudentResponseDTO;


@Service("StudentDAO")
public class StudentDAO {
	public static Connection con=null;
	static {
		con=Myconnection.getConnection();
	}
	public int insertData(StudentRequestDTO dto)
	{
		int result=0;
		String sql="insert into student(student_id,student_name,student_dob,student_gender,student_phone,student_education) values(?,?,?,?,?,?)";
		try
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getStudentId());
			ps.setString(2,dto.getStudentName());
			ps.setString(3,dto.getStudentDob());
			ps.setString(4,dto.getStudentGender());
			ps.setString(5,dto.getStudentPhone());
			ps.setString(6,dto.getStudentEducation());
			
			result=ps.executeUpdate();
			
		}
		catch(SQLException e)
		{
			System.out.println("Database error"+e.getMessage());
		}
		return result;
	}
	public int updateData(StudentRequestDTO dto)
	{
		int result=0;
		String sql="update student set student_name=?,student_dob=?,student_gender=?,student_phone=?,student_education=? where student_id=?";
		try
		{
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1,dto.getStudentName());
			ps.setString(2,dto.getStudentDob());
			ps.setString(3,dto.getStudentGender());
			ps.setString(4,dto.getStudentPhone());
			ps.setString(5,dto.getStudentEducation());
			
			ps.setString(6,dto.getStudentId());
			result=ps.executeUpdate();
			
		}catch(SQLException e)
		{
			System.out.println("Database error");
		}
		return result;
	}
	public int deleteData(StudentRequestDTO dto)
	{
		int result=0;
		String sql="delete from student where student_id=?";
		try
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getStudentId());
			result=ps.executeUpdate();
			
		}catch(SQLException e)
		{
			System.out.println("Database error");
		}
		return result;
	}
	public StudentResponseDTO selectOne(StudentRequestDTO dto)
	{
		StudentResponseDTO res=new StudentResponseDTO();
		String sql="select * from student where student_id=?";
		try
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getStudentId());
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				res.setStudentId(rs.getString("student_id"));
				res.setStudentName(rs.getString("student_name"));
				res.setStudentDob(rs.getString("student_dob"));
				res.setStudentGender(rs.getString("student_gender"));
				res.setStudentPhone(rs.getString("student_phone"));
				res.setStudentEducation(rs.getString("student_education"));
			
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return res;
		
		}

	public ArrayList<StudentResponseDTO> selectAll()
	{
		ArrayList<StudentResponseDTO> list=new ArrayList();
		String sql="select * from student";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				StudentResponseDTO res=new StudentResponseDTO();
				res.setStudentId(rs.getString("student_id"));
				res.setStudentName(rs.getString("student_name"));
				res.setStudentDob(rs.getString("student_dob"));
				res.setStudentGender(rs.getString("student_gender"));
				res.setStudentPhone(rs.getString("student_phone"));
				res.setStudentEducation(rs.getString("student_education"));
				
				list.add(res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public   List<StudentResponseDTO> search(StudentRequestDTO dto)
	{
		
		
		List <StudentResponseDTO>list=new ArrayList<>();
		String sql="select * from student where studen_id=? or student_name=? or student_course=?";
		try 
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getStudentId());
			ps.setString(2,dto.getStudentName());
		
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				
				StudentResponseDTO res=new StudentResponseDTO();
				res.setStudentId(rs.getString("student_id"));
				res.setStudentName(rs.getString("student_name"));
				res.setStudentDob(rs.getString("student_dob"));
				res.setStudentGender(rs.getString("student_gender"));
				res.setStudentPhone(rs.getString("student_phone"));
				res.setStudentEducation(rs.getString("student_education"));
				
				list.add(res);
				
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return list;
	}
	

	

}
