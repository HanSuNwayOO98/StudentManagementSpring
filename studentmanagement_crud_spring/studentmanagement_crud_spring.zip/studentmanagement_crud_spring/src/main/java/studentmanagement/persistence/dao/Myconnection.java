package studentmanagement.persistence.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Myconnection {
	static Connection con=null;
	public static Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentmanagement_crud_spring","root","Hsno2031998");
			System.out.println("Connecting....");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Driver class not Found");
		}
		catch(SQLException e)
		{
			System.out.println("Database not found");
		}
		return con;
	}

}
