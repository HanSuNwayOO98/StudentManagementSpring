package studentmanagement.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import studentmanagement.persistence.dto.CourseRequestDTO;
import studentmanagement.persistence.dto.CourseResponseDTO;

@Service("CourseDAO")
public class CourseDAO {
	
	
		public static Connection con=null;
		static
		{
			con=Myconnection.getConnection();
		}
		public int  insertCourseData(CourseRequestDTO dto)
		{
			int result=0;
			String sql="insert into course(course_id,course_name) values(?,?)";
			try 
			{
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString (1,dto.getCourseId());
				ps.setString (2,dto.getCourseName());
				
				
				result=ps.executeUpdate();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			return result;
		}
		public void updateCourseData(CourseRequestDTO dto) {
			String sql = "update course set course_name=? where course_id=?";

			try {
				PreparedStatement ps = con.prepareStatement(sql);

				ps.setString(1, dto.getCourseName());
				ps.setString(2, dto.getCourseId());
				ps.executeUpdate();
			} catch (SQLException e) {
				System.out.println("Database error");
			}

		}

		public void deleteCourseData(CourseRequestDTO dto) {
			String sql = "delete from course where course_id=?";

			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, dto.getCourseId());
				ps.executeUpdate();
			} catch (SQLException e) {
				System.out.println("Database error");
			}

		}

		public CourseResponseDTO selectOne(CourseRequestDTO dto) {
			CourseResponseDTO res = new CourseResponseDTO();
			String sql = "select * from course where course_id=?";
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, dto.getCourseId());
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					res.setCourseId(rs.getString("course_id"));
					res.setCourseName(rs.getString("course_name"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return res;

		}
		public ArrayList<CourseResponseDTO>selectAll()
		{
			ArrayList<CourseResponseDTO>list=new ArrayList();
			String sql="select * from course";
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					CourseResponseDTO res=new CourseResponseDTO();
					
					res.setCourseId(rs.getString("course_id"));
					res.setCourseName(rs.getString("course_name"));
				
					list.add(res);
				
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
		public int getId() {
			int res =0;
			String sql = "SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'studentmanagement_crud_spring' AND TABLE_NAME = 'course';";		
		
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				 while (rs.next()){
			            res=rs.getInt(1);
			        }
				System.out.println(res);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("error getiing ID");
				
				e.printStackTrace();
			}
			return res;
		}

	}


