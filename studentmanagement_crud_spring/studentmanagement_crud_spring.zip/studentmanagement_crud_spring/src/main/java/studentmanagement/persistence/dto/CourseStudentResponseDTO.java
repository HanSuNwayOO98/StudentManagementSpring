package studentmanagement.persistence.dto;

public class CourseStudentResponseDTO {
	private String courseName;
	private String studentId;
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	

}
